
const help = (prefix) => { 
	return `                 
*FITUR*
❀❀❀❀❀❀❀❀❀❀❀❀❀
*𝐵𝑂𝑇 𝐵𝑌 : 𝘳𝘢𝘮𝘢𝘳𝘮𝘥𝘩𝘯𝘪*
*NOTE : CMD HURUF KECIL*
*𝚂𝚌𝚛𝚒𝚙𝚝 : 𝚝𝚎𝚛𝚖𝚞𝚡 𝚘𝚗𝚕𝚢*
*𝐼𝐺 : 𝘳𝘢𝘮𝘢𝘳𝘮𝘥𝘩𝘯.𝘪𝘥*
❀❀❀❀❀❀❀❀❀❀❀❀❀
╭┈───────❮✿ ABOUT
╰─➤ *${prefix}OWNER
╰─➤ *${prefix}DONASI
╰─➤ *${prefix}INFO

╭┈───────❮✿ MARKER
╰─➤ *${prefix}STICKER
╰─➤ *${prefix}STICKER NOBG <ERROR>
╰─➤ *${prefix}TOIMG
╰─➤ *${prefix}TSTICKER
╰─➤ *${prefix}NULIS <ERROR>
 
╭┈───────❮✿ MEME
╰─➤ *${prefix}MEME
╰─➤ *${prefix}MEMEINDO

╭┈───────❮✿ MEDIA
╰─➤ *${prefix}TTS
╰─➤ *${prefix}LOLI
╰─➤ *${prefix}NSFWLOLI
╰─➤ *${prefix}URL2IMG
╰─➤ *${prefix}OCR
╰─➤ *${prefix}SIMI <ERROR>
╰─➤ *${prefix}TIKTOK

╭┈───────❮✿ GROUP
╰─➤ *${prefix}LINKGROUP
╰─➤ *${prefix}TAGALL
╰─➤ *${prefix}SIMIH <1/0>
╰─➤ *${prefix}NSFW <1/0>
╰─➤ *${prefix}GROUP <BUKA/TUTUP>
╰─➤ *${prefix}WELCOME <1/0>
╰─➤ *${prefix}PROMOTE <TAG>
╰─➤ *${prefix}DEMOTE <TAG>
╰─➤ *${prefix}CLONE <TAG>
╰─➤ *${prefix}SETPP
╰─➤ *${prefix}KICK <TAG>
╰─➤ *${prefix}ADD <628...>

╭┈───────❮✿ DOWNLOAD
╰─➤ *${prefix}YT <LINK> <TITID>

╭┈───────❮✿ OTHERS
╰─➤ *${prefix}YTSEARCH <TITID>
╰─➤ *${prefix}LISTADMIN
╰─➤ *${prefix}BLOCKLIST
╰─➤ *${prefix}FITNAH
╰─➤ *${prefix}TIKTOKSTALK
╰─➤ *${prefix}WAIT
╰─➤ *${prefix}HILIH
╰─➤ *${prefix}YT2MP3

╭┈───────❮✿ OWNER
╰─➤ *${prefix}BC
╰─➤ *${prefix}LEAVE
╰─➤ *${prefix}CLEARALL
╰─➤ *${prefix}SETPREFIX
╰─➤ *${prefix}BLOCK
╰─➤ *${prefix}UNBLOCK
❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀
❀━━━━━━━━━━━━━━━━━❀
❀-POWERED BY RAMA-       ❀
❀━━━━━━━━━━━━━━━━━❀
╭━━╮┈┈┈╭━━╮┈┈┈┈┈
┃╭╮┣━━━┫╭╮┃┈╭┳┳╮
╰━┳╯▆┈▆╰┳━╯┈┃┃┃┃
┈┈┃┓┈◯┈┏┃┈┈╭┫┗┗┃
┈┈┃╰┳┳┳╯┃┈┈┃┃╭━┃
╭━┻╮┗┻┛╭┻━╮╰┳━┳╯
┃┈┈╰━━━╯┈┈╰━┛┈┃┈
❀❀❀❀❀❀❀❀❀❀❀❀❀`
}
exports.help = help



  
