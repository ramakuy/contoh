const donasi = () => {
	return `𝑀𝐴𝑆𝐿𝐸𝑁𝑇

  Hi👋️
  
          MAU DONASI NI YA KAK
          

┣➥ *GOPAY:* 0816-5466-368
┣➥ *PULSA:* 0816-5466-368`
}

exports.donasi = donasi
